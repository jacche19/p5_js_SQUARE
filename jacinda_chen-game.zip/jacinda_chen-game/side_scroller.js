var w = window.innerWidth;
var h = window.innerHeight;
var jumper = new jumper();
var barrier = new barrier();
var platform = new platform();
var hit = false;
var score = 0;
var $ = document;
let bg;

/*function draw() {
  background(bg);

  stroke(226, 204, 0);
  line(0, y, width, y);

  y++;
  if (y > height) {
    y = 0;
  }
}*/

function setup() {
  bg = loadImage('background.png');
  ast = loadImage('asteroid.png');
  frameRate(120);
  createCanvas(w,h);
}

function draw() {
  clear();
  background(bg);
  /*
  var scoreNum = $.getElementById('score').innerHTML;
  scoreNum.appendChild(score);
  */
  jumper.show();
  barrier.show();
  platform.show();
  jumper.update();
  barrier.update();
  jumper.score();
  barrier.kill();
}

function jumper() {
  this.x = 50;
  this.y = 0;
  this.gravity = 1.5; //Force of gravity
  this.lift = -30; //Opposing force of gravity
  this.velocity = 0; //Velocity of player

  this.show = function() {
    fill(color('magenta'));
    ellipse(this.x, this.y, 50, 50);

  };

  this.up = function() {
    this.velocity += this.lift; //Jumping function
  };

  this.right = function() {
    if ((this.x < w) && (this.y > 0)) {
     this.x += 20;
    }
  };

  this.left = function() {
    if ((this.x < w) && (this.y > 0)) {
     this.x -= 20;
    }
  };

  this.update = function() {
    this.velocity += this.gravity; //Gravity applied when not jumping
    this.y += this.velocity;
    this.velocity *= 0.8; //air resistance
    if (this.y > (h*0.95)) { //for the floor
      this.y = h*0.95;
      this.velocity = 0;
    }
    if (this.y < 0) { //jumper hits the ceiling
      this.y = 0;
      this.velocity = 0;
    }
    if (((this.x < ((w/2) + 220)) && (this.x > (w/2))) && ((this.y < ((h/2) - 30)) &&  (this.y > ((h/2) - 40)))) { //if jumper lands on platform, it will stop falling
      this.velocity = 0;
      this.gravity = 0;
    }
    else {
      this.gravity = 1.5;
    }
  };

  this.score = function() {
    score++;
    $.getElementById('score').innerHTML = "SCORE: " + score;
    $.getElementById('end_score_head').innerHTML = "YOU GOT: " + score;
  };
}

function platform() {
  this.x = w/2;
  this.y = (h/2)-20;

  this.show = function() {
    fill(color("plum"));
    rect(this.x, this.y, 200, 30);
  };
}

function barrier() {
  this.x = w;
  this.y = Math.floor(Math.random()*(h));
  this.gravity = -2;
  this.velocity = -30;
  circleD = 100;

  this.show = function() {
    fill(color('darkorchid'));
    circle(this.x, this.y, circleD);
  };

  this.update = function() {
    this.velocity += this.gravity;
    this.x += this.velocity;
    this.velocity *= 0.8;
    if (this.x < -100) {
      this.x = w;
      this.velocity = -10;
      this.y = Math.floor(Math.random()*h);
      rectY = 50 + Math.floor(Math.random()*h/3);
    }
    //this.style.cssText = "animation: glow_box 1.5s ease-in-out infinite alternate; transition: all 0.5s";
  };

  this.kill = function() {
    hit = collideCircleCircle(this.x, this.y, circleD, jumper.x , jumper.y, 100);
    if (hit === true) {
      noLoop();
      $.getElementById("end").style.display = "inline";
    }
  };
}

function keyPressed() {
  if (keyCode === 32) { //space
    jumper.up();
  }
  if (keyCode === 37) { //left
    jumper.left();
  }
  if (keyCode === 39) { //right
    jumper.right();
  }
  //if "enter" key is pressed, restart game
  if (keyCode === 13) { //enter
    location.reload();
  }
}

function restart() {
  location.reload();
}
